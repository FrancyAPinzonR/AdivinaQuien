$(document).ready(function () {
    $('#exampleModalCenter').modal('toggle')
});